const config = {
    "port": 5690,
}

export default config